/*
 * Listens for events on the menu form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controllers;

import datacontainers.ClassroomDC;
import datacontainers.CourseDC;
import datacontainers.FacultyDC;
import datacontainers.StudentDC;
import utilities.ClassroomIO;
import utilities.CourseIO;
import utilities.FacultyIO;
import utilities.StudentIO;
import view.MainMenu;

import java.awt.event.ActionListener;
import java.util.logging.Level;

import static controllers.Application.getDEBUG_LOGGER;

public class MainMenuController implements ActionListener {

    // File location
    String persistedDataFileLocation;

    /**
     * Constructor
     * @param persistedDataFileLocation
     */

    public MainMenuController(String persistedDataFileLocation) {
        this.persistedDataFileLocation = persistedDataFileLocation;
    }
    
    // The data models are instantiated here and passed to the 
    // constructors for the controllers
    ClassroomDC datacontainer = new ClassroomDC();
    CourseDC courseContainer = new CourseDC();
    FacultyDC facultyContainer = new FacultyDC();
    StudentDC studentContainer = new StudentDC();

    
    // The main menu form gets created here. Notice it takes this controller object
    // as an argument to the constructor
    private MainMenu mainMenu = new MainMenu(this);

    /**
     * The ActionListener interface contains a single method, actionPerformed
     */
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String menuItemClicked = event.getActionCommand();

        // create the controller which will open the correct form
        if (menuItemClicked.equals("Add Classroom")) {
            InputClassroomFormController inputController = new InputClassroomFormController(datacontainer);
        } else if (menuItemClicked.equals("List Classrooms")) {
            ReportClassroomController reportController = new ReportClassroomController(datacontainer);
        } else if (menuItemClicked.equals("Add Course")) {
            InputCourseFormController inputCourseController = new InputCourseFormController(courseContainer, datacontainer);
        } else if (menuItemClicked.equals("List Courses")) {
            ReportCourseController reportCourseController = new ReportCourseController(courseContainer);
        } else if (menuItemClicked.equals("Add Faculty")){
            InputFacultyFormController inputFacultyController = new InputFacultyFormController(facultyContainer, courseContainer);
        } else if (menuItemClicked.equals("List Faculty")){
            ReportFacultyController reportFacultyController = new ReportFacultyController(facultyContainer);
        } else if (menuItemClicked.equals("Add Student")){
            InputStudentFormController inputStudentController = new InputStudentFormController(studentContainer, courseContainer);
        } else if (menuItemClicked.equals("List Students")){
            ReportStudentController reportStudentController = new ReportStudentController(studentContainer);
        }
        else if (menuItemClicked.equals("Exit")) {
            System.exit(0);      
        } else if (menuItemClicked.equals("Save Data")) {
            ClassroomIO.writeJSONFile(persistedDataFileLocation, datacontainer);
            CourseIO.writeJSONFile(persistedDataFileLocation, courseContainer);
            FacultyIO.writeJSONFile(persistedDataFileLocation, facultyContainer);
            StudentIO.writeJSONFile(persistedDataFileLocation, studentContainer);
        } else if (menuItemClicked.equals("Load Data")) {
            datacontainer.setListOfClassrooms(ClassroomIO.readJSONFile(persistedDataFileLocation));
            courseContainer.setListOfCourses(CourseIO.readJSONFile(persistedDataFileLocation));
            facultyContainer.setListOfFaculty(FacultyIO.readJSONFile(persistedDataFileLocation));
            studentContainer.setListOfStudents(StudentIO.readJSONFile(persistedDataFileLocation));
        } else if (menuItemClicked.equals("Log Warning")) {
            getDEBUG_LOGGER().setLevel(Level.WARNING);
        } else if (menuItemClicked.equals("Log Info")) {
            getDEBUG_LOGGER().setLevel(Level.INFO);
        } else if (menuItemClicked.equals("Log Severe")) {
            getDEBUG_LOGGER().setLevel(Level.SEVERE);
        } else if (menuItemClicked.equals("Log All")) {
            getDEBUG_LOGGER().setLevel(Level.ALL);
        }
    }

    // Getter used in the Application.java class
    public MainMenu getMainMenu() {
        return mainMenu;
    }
}
