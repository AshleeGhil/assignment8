package utilities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import datacontainers.FacultyDC;
import datamodels.Faculty;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FacultyIO {
    private FacultyIO(){

    }

    public static void writeJSONFile (String fileLocation, FacultyDC datacontainer) {
        PrintWriter jsonFile = null;
        try {
            jsonFile = new PrintWriter(fileLocation + "faculty.json");
            Gson gson = new GsonBuilder().create();
            gson.toJson(datacontainer.getListOfFaculty(), jsonFile);
        } catch (Exception exp) {
            // TO-DO
        } finally {
            jsonFile.flush();
            jsonFile.close();
        }
    }
    public static ArrayList<Faculty> readJSONFile(String fileLocation) {

        ArrayList<Faculty> listOfFaculty = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader(fileLocation + "faculty.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            Faculty[] facultyArray = gson.fromJson(jsonFile, Faculty[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < facultyArray.length; i++) {
                listOfFaculty.add(facultyArray[i]);
            }
        } catch (Exception exp) {
            // TO-DO
        } finally {
            return listOfFaculty;
        }
    }
}
