package utilities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import datacontainers.CourseDC;
import datamodels.Course;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;


public class CourseIO {

    private CourseIO(){

    }

    public static void writeJSONFile(String fileLocation, CourseDC datacontainers){

        PrintWriter jsonFile = null;

        try {
            jsonFile = new PrintWriter(fileLocation + "course.json");
            Gson gson = new GsonBuilder().create();
            gson.toJson(datacontainers.getListOfCourses(), jsonFile);
        } catch (Exception exp) {
            // TO-DO
        } finally {
            jsonFile.flush();
            jsonFile.close();
        }
    }

    public static ArrayList<Course> readJSONFile(String fileLocation) {

        ArrayList<Course> listOfCourses = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader(fileLocation + "course.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            Course[] courseArray = gson.fromJson(jsonFile, Course[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < courseArray.length; i++) {
                listOfCourses.add(courseArray[i]);
            }
        } catch (Exception exp) {
            // TO-DO
        } finally {
            return listOfCourses;
        }
    }

}

