package datamodels;

import exceptionhandlers.InvalidDataException;

import java.util.ArrayList;
import java.util.Iterator;

public class Student extends Person {

    private String studentID;
    private Float gpa;
    private java.time.LocalDate dateOfGraduation;
    private ArrayList<Course> listOfCourses = new ArrayList<Course>();

    public void setGPA (Float p_gpa) throws InvalidDataException{
      gpa = p_gpa;
        if (p_gpa <= 0.0f) {
            p_gpa = 0.0f;
            throw new InvalidDataException("Invalid GPA, setting to 0.0");
        }
    }

    public void setGPA (int gpa) throws InvalidDataException {
       if (gpa > 0){
           setGPA(Integer.valueOf(gpa).floatValue());
        }
    }

    public void setDateOfGraduation (java.time.LocalDate p_dateOfGraduation){
        dateOfGraduation = p_dateOfGraduation;
    }

    public void setStudentID (String p_studentID) throws InvalidDataException {
        if (p_studentID == null) {
            throw new InvalidDataException("Invalid Student ID:" + p_studentID);
        }
        if (!p_studentID.matches("^[0-9]{7}$")) {
            throw new InvalidDataException("Invalid Student ID:" + p_studentID);
        }
    }

    public void setStudentID (int studentID) throws InvalidDataException {
        if (studentID > 0) {
            setStudentID(Integer.valueOf(studentID).toString());
        }
    }

    public ArrayList<Course> getListOfCourses() {
        return listOfCourses;
    }

    public Float getGPA(){
        return gpa;
    }

    public java.time.LocalDate getDateOfGraduation(){

        return dateOfGraduation;

    }

    public String getStudentID() {
        return studentID;
    }

    public String toString() {
        String courses = "";
        Iterator iter = listOfCourses.iterator();
        while (iter.hasNext()) {
            courses += iter.next().toString() + ", ";
        }
        return "Student{" + "Name= " + name + ", Address= " + address + ", DateOfBirth= " + dateOfBirth + ", studentID= " + studentID + ", dateOfGraduation= " + dateOfGraduation + ", gpa= " + gpa + ", listOfCourses= " + courses + '}';
    }

}
