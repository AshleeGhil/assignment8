package datamodels;


import exceptionhandlers.InvalidDataException;
import interfaces.IClassroom;
import interfaces.ICourse;

public class Course implements ICourse {

    private String courseID;
    private String courseName;
    private Classroom classroom;

    @Override
    public void setCourseID(String p_courseID) throws InvalidDataException {
        if (p_courseID.length() == 0) {
            throw new InvalidDataException("No Course ID specified");
        }
        if (!p_courseID.matches("^[a-zA-Z]{4}[0-9]{3}$")) {
            throw new InvalidDataException("Invalid Course ID");
        }
        this.courseID = p_courseID;
    }

    @Override
    public void setCourseName(String p_courseName){ courseName = p_courseName;
    }

    @Override
    public void setClassroom(Classroom p_classroom) throws InvalidDataException {
        classroom = p_classroom;
    }

    @Override
    public String getCourseID() {
        return courseID;
    }

    @Override
    public String getCourseName() {
        return courseName;
    }

    @Override
    public IClassroom getClassroom() {
        return classroom;
    }


    public String toString() {
        return "Course{" + "courseID=" + courseID + ", courseName=" + courseName + ", Classroom=" + classroom + '}';
    }

}
