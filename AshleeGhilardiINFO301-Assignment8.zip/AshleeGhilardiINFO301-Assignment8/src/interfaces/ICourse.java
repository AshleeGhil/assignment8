package interfaces;

import datamodels.Classroom;
import exceptionhandlers.InvalidDataException;

public interface ICourse {

    public void setCourseID(String p_courseID) throws InvalidDataException;
    public void setCourseName(String p_courseName);
    public void setClassroom(Classroom p_classroom) throws InvalidDataException;

    public String getCourseID();
    public String getCourseName();
    public IClassroom getClassroom();

}
